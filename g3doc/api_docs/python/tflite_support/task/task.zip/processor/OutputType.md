page_type: reference
description: An enumeration.

<link rel="stylesheet" href="/site-assets/css/style.css">

<!-- DO NOT EDIT! Automatically generated file. -->


<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tflite_support.task.processor.OutputType" />
<meta itemprop="path" content="Stable" />
<meta itemprop="property" content="CATEGORY_MASK"/>
<meta itemprop="property" content="CONFIDENCE_MASK"/>
<meta itemprop="property" content="UNSPECIFIED"/>
</div>

# tflite_support.task.processor.OutputType

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">
<td>
  <a target="_blank" href="https://github.com/tensorflow/tflite-support/blob/v0.4.4/tensorflow_lite_support/python/task/processor/proto/segmentation_options.proto">
    <img src="https://www.tensorflow.org/images/GitHub-Mark-32px.png" />
    View source on GitHub
  </a>
</td>
</table>



An enumeration.

<!-- Placeholder for "Used in" -->




<!-- Tabular view -->
 <table class="responsive fixed orange">
<colgroup><col width="214px"><col></colgroup>
<tr><th colspan="2"><h2 class="add-link">Class Variables</h2></th></tr>

<tr>
<td>
CATEGORY_MASK<a id="CATEGORY_MASK"></a>
</td>
<td>
`<OutputType.CATEGORY_MASK: 1>`
</td>
</tr><tr>
<td>
CONFIDENCE_MASK<a id="CONFIDENCE_MASK"></a>
</td>
<td>
`<OutputType.CONFIDENCE_MASK: 2>`
</td>
</tr><tr>
<td>
UNSPECIFIED<a id="UNSPECIFIED"></a>
</td>
<td>
`<OutputType.UNSPECIFIED: 0>`
</td>
</tr>
</table>
